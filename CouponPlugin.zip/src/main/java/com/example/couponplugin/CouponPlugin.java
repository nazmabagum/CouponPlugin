package com.example.couponplugin;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.List;
import java.util.Map;

public class CouponPlugin extends JavaPlugin {

    private FileConfiguration config;

    @Override
    public void onEnable() {
        // Save default config if it doesn't exist
        saveDefaultConfig();
        config = getConfig();
        
        getLogger().info("CouponPlugin has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("CouponPlugin has been disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("redeem")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can use this command!");
                return true;
            }

            Player player = (Player) sender;

            if (args.length != 1) {
                player.sendMessage("Usage: /redeem <coupon-code>");
                return true;
            }

            String couponCode = args[0].toLowerCase();
            redeemCoupon(player, couponCode);
            return true;
        }
        
        if (cmd.getName().equalsIgnoreCase("createcoupon") && sender.hasPermission("coupon.admin")) {
            if (args.length < 2) {
                sender.sendMessage("Usage: /createcoupon <code> <command1> [command2...]");
                return true;
            }
            
            String code = args[0].toLowerCase();
            StringBuilder commands = new StringBuilder();
            
            for (int i = 1; i < args.length; i++) {
                commands.append(args[i]).append(" ");
            }
            
            config.set("coupons." + code, commands.toString().trim());
            saveConfig();
            sender.sendMessage("Coupon code '" + code + "' created!");
            return true;
        }
        
        return false;
    }

    private void redeemCoupon(Player player, String couponCode) {
        String commandString = config.getString("coupons." + couponCode);
        
        if (commandString == null) {
            player.sendMessage("Invalid coupon code!");
            return;
        }
        
        // Execute each command
        for (String command : commandString.split(";")) {
            if (command.trim().isEmpty()) continue;
            
            // Replace {player} with the player's name
            String processedCommand = command.trim()
                .replace("{player}", player.getName());
                
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
        }
        
        // Remove the coupon after redemption if configured to be single-use
        if (config.getBoolean("single-use", true)) {
            config.set("coupons." + couponCode, null);
            saveConfig();
        }
        
        player.sendMessage("Coupon redeemed successfully!");
    }
}